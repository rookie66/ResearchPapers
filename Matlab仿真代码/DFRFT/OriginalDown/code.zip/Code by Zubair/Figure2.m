% Clear Workspace and variables
clc 
clear all
close all

% Define all the required variables
n_SubCr = 8;
Taps = 2;
n_CP  = Taps-1;
FFT_points = 8;
n_SubCr_cp = FFT_points+n_CP;
EbN0dB = -20:5:50;EsN0dB = EbN0dB + 10*log10(n_SubCr/FFT_points) + 10*log10(FFT_points/n_SubCr_cp);
n_syms = 10000;
CFO = 0.15;
temp = 0.14;
FrFTFlag = 1;
alpha = 1.584;
fractFactor = [1.1313 1.1 1.081547 1.062541 1.04214 1.005];
BER = zeros(1,length(EbN0dB));BER_FRFT = zeros(1,length(EbN0dB));
for FrFTFlag = 1:1
    for i = 1:length(fractFactor)        
        for n = 1:length(EbN0dB)
            snr = EbN0dB(n);
            berrors = 0;            
            for symbols = 1:n_syms
                % Generating and BPSK modulating data
                x = rand(1,n_SubCr)>0.5;
                xt = 2*x -1;
                if(FrFTFlag)
                    xt = xt*dFRT(FFT_points,-fractFactor(i));
                else
                    xt = (FFT_points/sqrt(n_SubCr))*ifft(fftshift(xt),FFT_points);
                end
                % Adding CP
                xtt = [xt(end-n_CP+1:end) xt];
                %% Channel code
                ht = 1/sqrt(2)*1/sqrt(Taps)*(randn(1,Taps) + 1i*randn(1,Taps));
                if(FrFTFlag)
                    ht = [ht zeros(1,FFT_points-length(ht))];
                    hF = ht*dFRT(FFT_points,fractFactor(i));
                else
                    hF = fftshift(fft(ht,FFT_points,2));
                end
                % Data transmission
                xht = conv(ht,xtt);
                n_SubCr_cp = length(xht);
                nt = 1/sqrt(2)*(randn(1,n_SubCr_cp) + 1i*randn(1,n_SubCr_cp));
                yr = sqrt(n_SubCr_cp/FFT_points)*xht + 10^(-EsN0dB(n)/20)*nt;
                yr =(exp(1i*2*pi*temp(1)*(0:length(yr)-1)/FFT_points)).*yr;
                %% Receiver code
                yr = yr(n_CP+(1:FFT_points));
                if(FrFTFlag)
                    yr = yr*dFRT(FFT_points,fractFactor(i));
                else
                    yr = (n_SubCr/sqrt(FFT_points))*fftshift(fft(yr,FFT_points));
                end
                % Equalization and demodulation
                yr = yr./hF;
                yr = yr > 0;
                yr=sign(real(yr));
                berrors = berrors + length(find((yr-x)~=0));
            end
            if(FrFTFlag == 0)
                BER(i,n) = berrors/(FFT_points*n_syms);
            else
                BER_FRFT(i,n) = berrors/(FFT_points*n_syms);
            end
        end
    end
end
figure
semilogy((-10:5:60),BER_FRFT/2,'-d','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','b'); 
xlabel ('Eb/N0, dB');
ylabel ('BER');
legend ('alpha = 1.62','alpha = 1.5708 (pi/2)','alpha = 1.576','alpha = 1.58','alpha = 1.582','alpha = 1.584');
title ('BER sensitivity to CFO under Rayleigh multipath channel with nTap = 2');
axis([0 50 1e-4 1e0]);
grid on