% Clear workspace and all variables
clc
clear all
close all

% Define all the required variables
n_SubCr = 8;
Taps = 2;
n_CP  = Taps-1;
FFT_points = 8;
n_SubCr_cp = FFT_points+n_CP;
EbN0dB = -30:5:50;EsN0dB = EbN0dB + 10*log10(n_SubCr/FFT_points) + 10*log10(FFT_points/n_SubCr_cp);
n_syms = 10000;
CFO = 0.1:0.1:0.3;
eq = [2.3,1.325,1;0,0.4,0.4];
FrFTFlag = 1;
alpha = 1.584;
%Fraction factor
fractFactor = 1.1;
BER = zeros(1,length(EbN0dB));
BER_FRFT = zeros(1,length(EbN0dB));


for FrFTFlag = 0:1
    
    for ii = 1:length(CFO)
        
        for n = 1:length(EbN0dB)
            snr = EbN0dB(n);
            berrors = 0;tic;
            
            for mc = 1:n_syms
                % Data Generation and BPSK modulation
                x = rand(1,n_SubCr)>0.5;
                xt = 2*x -1;
                if(FrFTFlag)
                    xt = xt*dFRT(FFT_points,-fractFactor);
                else
                    xt = (FFT_points/sqrt(n_SubCr))*ifft(fftshift(xt),FFT_points);
                end
                xtt = [xt(end-n_CP+1:end) xt];
                %% Channel code
                ht = 1/sqrt(2)*1/sqrt(Taps)*(randn(1,Taps) + 1i*randn(1,Taps));
                if(FrFTFlag)
                    ht = [ht zeros(1,FFT_points-length(ht))];
                    hF = ht*dFRT(FFT_points,fractFactor);
                else
                    hF = fftshift(fft(ht,FFT_points,2));
                end
                % Transmittion
                xht  = conv(ht,xtt);
                n_SubCr_cp = length(xht);
                nt = 1/sqrt(2)*(randn(1,n_SubCr_cp) + 1i*randn(1,n_SubCr_cp));
                yr = sqrt(n_SubCr_cp/FFT_points)*xht + 10^(-EsN0dB(n)/20)*nt;
                % Applying CFO
                yr =(exp(1i*2*pi*eq(FrFTFlag+1,ii)*CFO(ii)*(0:length(yr)-1)/FFT_points)).*yr;
                
                %% Receiver Code
                yr = yr(n_CP+(1:FFT_points)); % Removing cyclic prefix
                if(FrFTFlag)
                    yr = yr*dFRT(FFT_points,fractFactor);
                else
                    yr = (n_SubCr/sqrt(FFT_points))*fftshift(fft(yr,FFT_points));
                end
                % Equalization & Demodulation
                yr = yr./hF;
                yr = yr > 0;
                yr=sign(real(yr));
                % BER Calculation
                berrors = berrors + length(find((yr-x)~=0));
            end
            if(FrFTFlag == 0)
                BER(ii,n) = berrors/(FFT_points*n_syms);
            else
                BER_FRFT(ii,n) = berrors/(FFT_points*n_syms);
            end
        end
        %% Plotting Simulation Results
        figure(1);
        if(FrFTFlag == 0)
            h1(ii) = semilogy((-20:5:60),BER(ii,:)/2,'--kx','LineWidth',2,'MarkerSize',12,'MarkerEdgeColor','k');
        else
            h2(ii) = semilogy((-20:5:60),BER_FRFT(ii,:)/2,'-bx','LineWidth',2,'MarkerSize',12,'MarkerEdgeColor','b');
        end
        hold on
    end
end
h3 = [h1 h2];
h4 = h3([1,4]);
xlabel ('Eb/N0, dB');
ylabel ('BER');
legend ('CFO = 0.1','CFO = 0.2','CFO = 0.3');
legend (h4, {'FFT','FRFT'});
title ('BER sensitivity to CFO under Rayleigh multipath channel with nTap = 2');
axis([0 50 1e-4 1e0]);
grid on